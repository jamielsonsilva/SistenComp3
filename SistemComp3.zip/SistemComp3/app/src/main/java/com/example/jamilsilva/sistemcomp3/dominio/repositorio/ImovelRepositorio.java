package com.example.jamilsilva.sistemcomp3.dominio.repositorio;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.jamilsilva.sistemcomp3.dominio.entidades.Imovel;

import java.util.ArrayList;
import java.util.List;

public class ImovelRepositorio {

    private SQLiteDatabase conexao;

    public ImovelRepositorio(SQLiteDatabase conexao){
        this.conexao = conexao;
    }

    public void inserir(Imovel  imovel){

        ContentValues  contentValues = new ContentValues();
        contentValues.put("DESCRICAO", imovel.descricao);
        contentValues.put("ENDERECO",  imovel.endereco);
        contentValues.put("SITUACAO", imovel.ocupDesoc);
        contentValues.put("PRECO", imovel.preco);
        contentValues.put("BANHEIRO", imovel.banheiro);
        contentValues.put("QUARTOS", imovel.quartos);
        contentValues.put("SALAS", imovel.salas);

        conexao.insertOrThrow("IMOVEL", null, contentValues);

    }

    public void excluir(int codigo){

        String[] parametros = new String[1];
        parametros[0] = String.valueOf(codigo);

        conexao.delete("IMOVEL","CODIGO = ?", parametros );


    }

    public void alterar(Imovel imovel){

        ContentValues  contentValues = new ContentValues();
        contentValues.put("DESCRICAO", imovel.descricao);
        contentValues.put("ENDERECO",  imovel.endereco);
        contentValues.put("SITUACAO", imovel.ocupDesoc);
        contentValues.put("PRECO", imovel.preco);
        contentValues.put("BANHEIRO", imovel.banheiro);
        contentValues.put("QUARTOS", imovel.quartos);
        contentValues.put("SALAS", imovel.salas);

        String[] parametros = new String[1];
        parametros[0] = String.valueOf(imovel.codigo);

        conexao.update("IMOVEL", contentValues, "CODIGO = ?", parametros);

    }

    public List<Imovel> buscarTodos(){

        List<Imovel> imoveis = new ArrayList<Imovel>() ;

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT CODIGO,DESCRICAO,ENDERECO,SITUACAO,PRECO,BANHEIRO,QUARTOS,SALAS ");
        sql.append(" FROM IMOVEL");

        Cursor resultado = conexao.rawQuery(sql.toString(),null);

        if (resultado.getCount() > 0){

            resultado.moveToFirst();

            do{

                Imovel imo = new Imovel();
                imo.codigo    = resultado.getInt(resultado.getColumnIndexOrThrow("CODIGO"));
                imo.descricao = resultado.getString(resultado.getColumnIndexOrThrow("DESCRICAO"));
                imo.endereco  = resultado.getString(resultado.getColumnIndexOrThrow("ENDERECO"));
                imo.ocupDesoc = resultado.getString(resultado.getColumnIndexOrThrow("SITUACAO"));
                imo.preco     = resultado.getString(resultado.getColumnIndexOrThrow("PRECO"));
                imo.banheiro  = resultado.getString(resultado.getColumnIndexOrThrow("BANHEIRO"));
                imo.quartos   = resultado.getString(resultado.getColumnIndexOrThrow("QUARTOS"));
                imo.salas     = resultado.getString(resultado.getColumnIndexOrThrow("SALAS"));

                imoveis.add(imo);

            }while (resultado.moveToNext());
        }

        return imoveis;
    }

    public Imovel buscarImovel(int codigo){

        Imovel imovel = new Imovel();

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT CODIGO,DESCRICAO,ENDERECO,SITUACAO,PRECO,BANHEIRO,QUARTOS,SALAS ");
        sql.append(" FROM IMOVEL");
        sql.append(" WHERE CODIGO = ?");

        String[] parametros = new String[1];
        parametros[0] = String.valueOf(codigo);

        Cursor resultado = conexao.rawQuery(sql.toString(),parametros);

        if(resultado.getCount() > 0){

            resultado.moveToFirst();

            imovel.codigo      = resultado.getInt(resultado.getColumnIndexOrThrow("CODIGO"));
            imovel.descricao   = resultado.getString(resultado.getColumnIndexOrThrow("DESCRICAO"));
            imovel.endereco    = resultado.getString(resultado.getColumnIndexOrThrow("ENDERECO"));
            imovel.ocupDesoc   = resultado.getString(resultado.getColumnIndexOrThrow("SITUACAO"));
            imovel.preco       = resultado.getString(resultado.getColumnIndexOrThrow("PRECO"));
            imovel.banheiro    = resultado.getString(resultado.getColumnIndexOrThrow("BANHEIRO"));
            imovel.quartos     = resultado.getString(resultado.getColumnIndexOrThrow("QUARTOS"));
            imovel.salas       = resultado.getString(resultado.getColumnIndexOrThrow("SALAS"));

            return imovel;

        }

        return null;

    }
}
