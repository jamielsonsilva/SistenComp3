package com.example.jamilsilva.sistemcomp3.dominio.entidades;

public class Imovel {

    public int codigo;
    public String descricao;
    public String endereco;
    public String ocupDesoc;
    public String preco;
    public String banheiro;
    public String quartos;
    public String salas;

}
