package com.example.jamilsilva.sistemcomp3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ActTelaPrinc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_tela_princ);
    }

    public void TelaImovCadast(View view){
        Intent intent1 = new Intent(ActTelaPrinc.this, ActImovCadast.class);
        startActivity(intent1);
    }
}
