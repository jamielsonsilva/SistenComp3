package com.example.jamilsilva.sistemcomp3;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;

import com.example.jamilsilva.sistemcomp3.database.DadosOpenHelper;
import com.example.jamilsilva.sistemcomp3.dominio.entidades.Imovel;
import com.example.jamilsilva.sistemcomp3.dominio.repositorio.ImovelRepositorio;

public class ActCadastImov extends AppCompatActivity {

    private EditText edtCodigo;
    private EditText edtDescricao;
    private EditText edtEndereco;
    private EditText edtOcupDesoc;
    private EditText edtPreco;
    private EditText edtBanheiro;
    private EditText edtQuantQuartos;
    private EditText edtQuartos;
    private ConstraintLayout layout_act_cadast_imov;

    private ImovelRepositorio imovelRepositorio;

    private SQLiteDatabase conexao;

    private DadosOpenHelper dadosOpenHelper;

    private Imovel imovel;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_cadast_imov);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        edtCodigo       = (EditText)findViewById(R.id.edtCodigo);
        edtDescricao    = (EditText)findViewById(R.id.edtDescricao);
        edtEndereco     = (EditText)findViewById(R.id.edtEndereco);
        edtOcupDesoc    = (EditText)findViewById(R.id.edtOcupDesoc);
        edtPreco        = (EditText)findViewById(R.id.edtPreco);
        edtBanheiro     = (EditText)findViewById(R.id.edtBanheiro);
        edtQuantQuartos = (EditText)findViewById(R.id.edtQuantQuartos);
        edtQuartos      = (EditText)findViewById(R.id.edtQuartos);

        layout_act_cadast_imov = (ConstraintLayout)findViewById(R.id.layout_act_cadast_imov);

        criarConexao();

    }

    private void criarConexao(){

        try{

            dadosOpenHelper = new DadosOpenHelper(this);

            conexao = dadosOpenHelper.getWritableDatabase();

            Snackbar.make(layout_act_cadast_imov, R.string.message_conexao_criada_com_sucesso, Snackbar.LENGTH_LONG)
                    .setAction(R.string.action_ok, null).show();

             imovelRepositorio = new ImovelRepositorio(conexao);

        }catch (SQLException ex){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle(R.string.title_message_erro);
            dlg.setMessage(ex.getMessage());
            dlg.setNeutralButton(R.string.action_ok,null);
            dlg.show();

        }

    }

    private void confirmar(){

        imovel = new Imovel();

        if (validarCampos() == false ){

            try{

                 imovelRepositorio.inserir(imovel);

                 finish();

            }catch (SQLException ex){

                AlertDialog.Builder dlg = new AlertDialog.Builder(this);
                dlg.setTitle(R.string.title_message_erro);
                dlg.setMessage(ex.getMessage());
                dlg.setNeutralButton(R.string.action_ok,null);
                dlg.show();

            }

        }

    }

    private boolean validarCampos(){

        boolean res = false;


        String descricao = edtDescricao.getText().toString();
        String endereco  = edtEndereco.getText().toString();
        String ocupDesoc = edtOcupDesoc.getText().toString();
        String preco     = edtPreco.getText().toString();
        String banheiro  = edtBanheiro.getText().toString();
        String quartos   = edtQuantQuartos.getText().toString();
        String salas     = edtQuartos.getText().toString();


        imovel.descricao = descricao;
        imovel.endereco  = endereco;
        imovel.ocupDesoc = ocupDesoc;
        imovel.preco     = preco;
        imovel.banheiro  = banheiro;
        imovel.quartos   = quartos;
        imovel.salas     = salas;


                if (res = isCampoVazio(descricao)){
                edtDescricao.requestFocus();
                }
                else
                    if (res = isCampoVazio(endereco)){
                    edtEndereco.requestFocus();
                    }
                    else
                        if (res = isCampoVazio(ocupDesoc)){
                        edtOcupDesoc.requestFocus();
                        }
                        else
                            if (res = isCampoVazio(preco)){
                            edtPreco.requestFocus();
                            }
                            else
                                if (res = isCampoVazio(banheiro)){
                                edtBanheiro.requestFocus();
                                }
                                else
                                    if (res = isCampoVazio(quartos)){
                                    edtQuantQuartos.requestFocus();
                                    }
                                    else
                                        if (res = isCampoVazio(salas)){
                                        edtQuartos.requestFocus();
                                        }

        if (res){

            AlertDialog.Builder dlg = new AlertDialog.Builder(this);
            dlg.setTitle(R.string.title_aviso);
            dlg.setMessage(R.string.message_campos_invalidos_brancos);
            dlg.setNeutralButton(R.string.action_ok, null);
            dlg.show();

        }

        return res;

    }


    private boolean isCampoVazio(String valor){

        boolean resultado = (TextUtils.isEmpty(valor) || valor.trim().isEmpty());
        return resultado;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_act_cad_imov, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id){

            case R.id.action_ok:

                confirmar();


                break;

            case R.id.action_cancelar:


                finish();

                break;
        }

        return super.onOptionsItemSelected(item);
    }

    public void setImovel(Imovel imovel) {
        this.imovel = imovel;
    }
}
