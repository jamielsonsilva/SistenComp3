package com.example.jamilsilva.sistemcomp3.database;

public class ScriptDDL {
    public static String getCreateTableImovel() {

        StringBuilder sql = new StringBuilder();

        sql.append (" CREATE TABLE IF NOT EXISTS IMOVEL (");
        sql.append ("       codigo INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,");
        sql.append ("       descricao VACHAR (250) NOT NULL DEFAULT(''), ");
        sql.append ("       endereco  VACHAR(250)  NOT NULL DEFAULT(''), ");
        sql.append ("       ocupDesoc VACHAR(250)  NOT NULL DEFAULT(''),");
        sql.append ("       preco     VACHAR(250)   NOT NULL DEFAULT(''),");
        sql.append ("       banheiro  VACHAR(250)   NOT NULL DEFAULT(''),");
        sql.append ("       quartos   VACHAR(250)   NOT NULL DEFAULT(''),");
        sql.append ("       salas     VACHAR(250)   NOT NULL DEFAULT('') )");

        return sql.toString();

    }

}
